<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../admin_login.php"); // Redirect to login if not an admin
    exit();
}

// Handle search functionality
$searchTerm = '';
if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['search_term']);
}

// Query to get all categories
$sql = "SELECT * FROM categories";
if ($searchTerm) {
    $sql .= " WHERE category_name LIKE '%$searchTerm%'";
}
$result = $conn->query($sql);

// Handle deletion of categories
if (isset($_GET['delete_category'])) {
    $category_id = intval($_GET['category_id']);
    $deleteSql = "DELETE FROM categories WHERE category_id = $category_id";
    
    if ($conn->query($deleteSql) === TRUE) {
        $successMessage = "Category deleted successfully.";
    } else {
        $errorMessage = "Error deleting category: " . $conn->error;
    }

    // Refresh the page to see the updated category list
    header("Refresh:0");
}

// Fetch category details for editing (if necessary)
$categoryToEdit = null;
if (isset($_POST['edit_category_id'])) {
    $editCategoryId = intval($_POST['edit_category_id']);
    $categorySql = "SELECT * FROM categories WHERE category_id = $editCategoryId";
    $categoryResult = $conn->query($categorySql);
    $categoryToEdit = $categoryResult->fetch_assoc();
}

// Handle updating category details
if (isset($_POST['update_category'])) {
    $editCategoryId = intval($_POST['edit_category_id']);
    $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
    
    $updateSql = "UPDATE categories SET category_name = '$category_name' WHERE category_id = $editCategoryId";
    if ($conn->query($updateSql) === TRUE) {
        $successMessage = "Category updated successfully.";
    } else {
        $errorMessage = "Error updating category: " . $conn->error;
    }

    // Refresh the page to see the updated category list
    header("Refresh:0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin-styles.css"> <!-- Custom styles for admin panel -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Manage Categories</h2>

        <?php if (isset($successMessage)) { ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php } ?>
        <?php if (isset($errorMessage)) { ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php } ?>

        <form method="POST" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" name="search_term" placeholder="Search by category name" value="<?php echo htmlspecialchars($searchTerm); ?>">
                <button type="submit" name="search" class="btn btn-primary">Search</button>
            </div>
        </form>

        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Category ID</th>
                    <th>Category Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['category_id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['category_name']) . "</td>";
                        echo "<td>
                                <button type='button' class='btn btn-warning btn-sm' onclick='editCategory(" . htmlspecialchars($row['category_id']) . ")'>Edit</button>
                                <a href='?delete_category=true&category_id=" . htmlspecialchars($row['category_id']) . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3' class='text-center'>No categories found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div class="text-center mt-4">
            <a href="admin_dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" id="editCategoryForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="edit_category_id" id="edit_category_id" value="">
                        <div class="mb-3">
                            <label for="category_name" class="form-label">Category Name</label>
                            <input type="text" class="form-control" id="category_name" name="category_name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update_category" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editCategory(categoryId) {
            // Fetch category data via AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'get_category.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    const category = JSON.parse(xhr.responseText);
                    // Populate the modal fields with category data
                    document.getElementById('edit_category_id').value = category.category_id;
                    document.getElementById('category_name').value = category.category_name;
                    // Show the modal
                    var editModal = new bootstrap.Modal(document.getElementById('editCategoryModal'));
                    editModal.show();
                }
            };
            xhr.send('category_id=' + categoryId);
        }
    </script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

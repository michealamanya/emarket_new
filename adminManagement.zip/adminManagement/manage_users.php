<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../admin_login.php"); // Redirect to login if not an admin
    exit();
}

// Handle search functionality
$searchTerm = '';
if (isset($_POST['search'])) {
    $searchTerm = mysqli_real_escape_string($conn, $_POST['search_term']);
}

// Query to get all users
$sql = "SELECT * FROM users";
if ($searchTerm) {
    $sql .= " WHERE username LIKE '%$searchTerm%' OR email LIKE '%$searchTerm%'";
}
$result = $conn->query($sql);

// Handle deletion of users
if (isset($_GET['delete_user'])) {
    $user_id = intval($_GET['user_id']);
    $deleteSql = "DELETE FROM users WHERE user_id = $user_id";
    
    if ($conn->query($deleteSql) === TRUE) {
        $successMessage = "User deleted successfully.";
    } else {
        $errorMessage = "Error deleting user: " . $conn->error;
    }

    // Refresh the page to see the updated user list
    header("Refresh:0");
}

// Fetch user details for editing (if necessary)
$userToEdit = null;
if (isset($_POST['edit_user_id'])) {
    $editUserId = intval($_POST['edit_user_id']);
    $userSql = "SELECT * FROM users WHERE user_id = $editUserId";
    $userResult = $conn->query($userSql);
    $userToEdit = $userResult->fetch_assoc();
}

// Handle updating user details
if (isset($_POST['update_user'])) {
    $editUserId = intval($_POST['edit_user_id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    
    $updateSql = "UPDATE users SET username = '$username', email = '$email', role = '$role' WHERE user_id = $editUserId";
    if ($conn->query($updateSql) === TRUE) {
        $successMessage = "User updated successfully.";
    } else {
        $errorMessage = "Error updating user: " . $conn->error;
    }

    // Refresh the page to see the updated user list
    header("Refresh:0");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin-styles.css"> <!-- Custom styles for admin panel -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Manage Users</h2>

        <?php if (isset($successMessage)) { ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php } ?>
        <?php if (isset($errorMessage)) { ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php } ?>

        <form method="POST" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" name="search_term" placeholder="Search by username or email" value="<?php echo htmlspecialchars($searchTerm); ?>">
                <button type="submit" name="search" class="btn btn-primary">Search</button>
            </div>
        </form>

        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['user_id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                        echo "<td>
                                <button type='button' class='btn btn-warning btn-sm' onclick='editUser(" . htmlspecialchars($row['user_id']) . ")'>Edit</button>
                                <a href='?delete_user=true&user_id=" . htmlspecialchars($row['user_id']) . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No users found</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div class="text-center mt-4">
            <a href="../admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="POST" id="editUserForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="edit_user_id" id="edit_user_id" value="">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <input type="text" class="form-control" id="role" name="role" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update_user" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editUser(userId) {
            // Fetch user data via AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'get_user.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    const user = JSON.parse(xhr.responseText);
                    // Populate the modal fields with user data
                    document.getElementById('edit_user_id').value = user.user_id;
                    document.getElementById('username').value = user.username;
                    document.getElementById('email').value = user.email;
                    document.getElementById('role').value = user.role;
                    // Show the modal
                    var editModal = new bootstrap.Modal(document.getElementById('editUserModal'));
                    editModal.show();
                }
            };
            xhr.send('user_id=' + userId);
        }
    </script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

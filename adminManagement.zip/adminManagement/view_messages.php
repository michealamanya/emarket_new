<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../admin_login.php"); // Redirect to login if not an admin
    exit();
}

// Query to get all messages with user information
$sql = "SELECT m.message_id, m.sender_id, m.content, m.sent_at, u.username 
        FROM messages AS m
        JOIN users AS u ON m.sender_id = u.user_id
        ORDER BY m.sent_at DESC";

$result = $conn->query($sql);

// Handle deletion of messages
if (isset($_GET['delete_message'])) {
    $message_id = intval($_GET['message_id']);
    $deleteSql = "DELETE FROM messages WHERE message_id = $message_id";
    
    if ($conn->query($deleteSql) === TRUE) {
        $successMessage = "Message deleted successfully.";
    } else {
        $errorMessage = "Error deleting message: " . $conn->error;
    }

    // Refresh the page to see the updated message list
    header("Refresh:0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Messages</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin-styles.css"> <!-- Custom styles for admin panel -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">User Messages</h2>

        <?php if (isset($successMessage)) { ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php } ?>
        <?php if (isset($errorMessage)) { ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php } ?>

        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Message ID</th>
                    <th>Sender</th>
                    <th>Message Content</th>
                    <th>Sent At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['message_id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['content']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['sent_at']) . "</td>";
                        echo "<td>
                                <a href='?delete_message=true&message_id=" . htmlspecialchars($row['message_id']) . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No messages found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <div class="text-center mt-4">
            <a href="../admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

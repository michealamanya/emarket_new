<?php
session_start();
include '../db_connect.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit();
}

// Validate and sanitize input
$setting = $_POST['setting'];
$value = $_POST['value'];

$allowedSettings = ['font', 'theme'];
if (!in_array($setting, $allowedSettings)) {
    echo json_encode(['success' => false, 'message' => 'Invalid setting.']);
    exit();
}

// Update the settings in the database
$sql = "UPDATE settings SET $setting = ? WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $value, $_SESSION['user_id']); // Assuming user_id is the admin's ID

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
}

$stmt->close();
$conn->close();
?>

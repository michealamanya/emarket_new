<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("HTTP/1.0 403 Forbidden");
    exit();
}

// Get the category ID from the request
if (isset($_POST['category_id'])) {
    $category_id = intval($_POST['category_id']);
    $sql = "SELECT * FROM categories WHERE category_id = $category_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Return category data as JSON
        echo json_encode($result->fetch_assoc());
    } else {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}

// Close the database connection
$conn->close();
?>

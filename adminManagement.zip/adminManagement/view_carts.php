<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Check if the user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../admin_login.php"); // Redirect to login if not an admin
    exit();
}

// Query to get all carts with user information
$sql = "SELECT c.cart_id, c.user_id, c.product_id, c.quantity, p.name AS product_name, u.username 
        FROM cart AS c
        JOIN products AS p ON c.product_id = p.product_id
        JOIN users AS u ON c.user_id = u.user_id
        ORDER BY c.cart_id DESC";

$result = $conn->query($sql);

// Handle settling the cart
if (isset($_POST['settle_cart'])) {
    $cart_id = intval($_POST['cart_id']);
    
    // Move items from cart to orders (assuming you have an orders table)
    $settleSql = "INSERT INTO orders (user_id, product_id, quantity, order_date, status) 
                  SELECT user_id, product_id, quantity, NOW(), 'Pending' 
                  FROM cart WHERE cart_id = $cart_id";
    
    // Delete from cart after settling
    $deleteSql = "DELETE FROM cart WHERE cart_id = $cart_id";
    
    if ($conn->query($settleSql) === TRUE && $conn->query($deleteSql) === TRUE) {
        $successMessage = "Cart settled successfully.";
    } else {
        $errorMessage = "Error settling cart: " . $conn->error;
    }

    // Refresh the page to see the updated cart list
    header("Refresh:0");
}

// Handle deletion of the cart
if (isset($_GET['delete_cart'])) {
    $cart_id = intval($_GET['cart_id']);
    $deleteSql = "DELETE FROM cart WHERE cart_id = $cart_id";
    
    if ($conn->query($deleteSql) === TRUE) {
        $successMessage = "Cart deleted successfully.";
    } else {
        $errorMessage = "Error deleting cart: " . $conn->error;
    }

    // Refresh the page to see the updated cart list
    header("Refresh:0");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Carts</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="admin-styles.css"> <!-- Custom styles for admin panel -->
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">User Carts</h2>

        <?php if (isset($successMessage)) { ?>
            <div class="alert alert-success"><?php echo $successMessage; ?></div>
        <?php } ?>
        <?php if (isset($errorMessage)) { ?>
            <div class="alert alert-danger"><?php echo $errorMessage; ?></div>
        <?php } ?>

        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Cart ID</th>
                    <th>Username</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data for each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['cart_id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                        echo "<td>
                                <form method='POST' action=''>
                                    <input type='hidden' name='cart_id' value='" . htmlspecialchars($row['cart_id']) . "'>
                                    <button type='submit' name='settle_cart' class='btn btn-success btn-sm'>Settle Cart</button>
                                    <a href='edit_cart.php?cart_id=" . htmlspecialchars($row['cart_id']) . "' class='btn btn-warning btn-sm'>Edit</a>
                                    <a href='?delete_cart=true&cart_id=" . htmlspecialchars($row['cart_id']) . "' class='btn btn-danger btn-sm'>Delete</a>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No carts found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <div class="text-center mt-4">
            <a href="../admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

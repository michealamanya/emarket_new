<?php
// Start a session
session_start();

// Include the database connection
include '../db_connect.php';

// Fetch current settings from the database
$sql = "SELECT * FROM settings WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']); // Assuming user_id is the admin's ID
$stmt->execute();
$result = $stmt->get_result();
$currentSettings = $result->fetch_assoc();

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f4f7fa;
        }
        .dark-mode {
            background-color: #343a40;
            color: white;
        }
    </style>
</head>
<body class="<?php echo $currentSettings['mode'] === 'dark' ? 'dark-mode' : ''; ?>">

    <div class="container mt-5">
        <h2 class="text-center">Settings</h2>
        <div class="mb-4">
            <label for="fontSelect" class="form-label">Select Font Style:</label>
            <select id="fontSelect" class="form-select" onchange="updateSettings('font', this.value)">
                <option value="Arial" <?php if ($currentSettings['font'] === 'Arial') echo 'selected'; ?>>Arial</option>
                <option value="Courier New" <?php if ($currentSettings['font'] === 'Courier New') echo 'selected'; ?>>Courier New</option>
                <option value="Georgia" <?php if ($currentSettings['font'] === 'Georgia') echo 'selected'; ?>>Georgia</option>
                <option value="Times New Roman" <?php if ($currentSettings['font'] === 'Times New Roman') echo 'selected'; ?>>Times New Roman</option>
            </select>
        </div>

        <div>
            <label class="form-label">Theme:</label><br>
            <button class="btn btn-light" onclick="updateSettings('theme', 'light')">Light Mode</button>
            <button class="btn btn-dark" onclick="updateSettings('theme', 'dark')">Dark Mode</button>
        </div>

        <div class="mt-4">
            <a href="admin_dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        function updateSettings(setting, value) {
            $.ajax({
                url: 'save_settings.php',
                type: 'POST',
                data: { setting: setting, value: value },
                success: function(response) {
                    if (response.success) {
                        alert('Settings updated successfully.');
                        if (setting === 'theme') {
                            // Reload the page to apply the theme change
                            location.reload();
                        }
                    } else {
                        alert('Failed to update settings.');
                    }
                },
                error: function() {
                    alert('Error in AJAX request.');
                }
            });
        }
    </script>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>

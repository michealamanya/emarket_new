<?php
include 'db_connect.php';

if (isset($_POST['id'])) {
    $productId = $_POST['id'];
    $sql = "SELECT * FROM products WHERE product_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $productId);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    
    echo json_encode($product);
}

$conn->close();
?>

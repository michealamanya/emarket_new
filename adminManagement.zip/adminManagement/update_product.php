<?php
include '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['product_id'];
    $productName = $_POST['product_name'];
    $productDescription = $_POST['product_description'];
    $productPrice = $_POST['product_price'];
    $productStock = $_POST['product_stock'];

    $sql = "UPDATE products SET name=?, description=?, price=?, stock=? WHERE product_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiii", $productName, $productDescription, $productPrice, $productStock, $productId);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}

$conn->close();
?>

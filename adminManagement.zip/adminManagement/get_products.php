<?php
// db_connect.php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "e_market"; 

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products - Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f4f7fa;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            min-height: 100vh;
        }
        .sidebar a {
            color: white;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            padding: 20px;
        }
    </style>
</head>
<body>

    <div class="d-flex">
        <nav class="sidebar p-3">
            <h4>Admin Panel</h4>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="bi bi-house-door"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_users.php"><i class="bi bi-person"></i> Manage Users</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_messages.php"><i class="bi bi-envelope"></i> View Messages</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_carts.php"><i class="bi bi-cart"></i> View Carts</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_products.php"><i class="bi bi-box"></i> Manage Products</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="manage_categories.php"><i class="bi bi-tags"></i> Manage Categories</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_requests.php"><i class="bi bi-bell"></i> User Requests</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
                </li>
            </ul>
        </nav>

        <div class="content flex-grow-1">
            <h2 class="mb-4">Manage Products</h2>
            <input type="text" id="productSearch" class="form-control mb-3" placeholder="Search for products...">
            <table class="table table-striped" id="productTable">
                <thead>
                    <tr>
                        <th scope="col">Product ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Price</th>
                        <th scope="col">Stock</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch products from the database
                    $sql = "SELECT * FROM products";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['product_id']}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['description']}</td>
                                    <td>{$row['price']}</td>
                                    <td>{$row['stock']}</td>
                                    <td>
                                        <button class='btn btn-warning btn-sm' onclick='editProduct({$row['product_id']})'>Edit</button>
                                        <button class='btn btn-danger btn-sm' onclick='deleteProduct({$row['product_id']})'>Delete</button>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No products found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form id="editProductForm">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editProductModalLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="edit_product_id" name="product_id" value="">
                        <div class="mb-3">
                            <label for="edit_product_name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="edit_product_name" name="product_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_product_description" class="form-label">Description</label>
                            <textarea class="form-control" id="edit_product_description" name="product_description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_product_price" class="form-label">Price</label>
                            <input type="number" class="form-control" id="edit_product_price" name="product_price" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_product_stock" class="form-label">Stock</label>
                            <input type="number" class="form-control" id="edit_product_stock" name="product_stock" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Product search functionality
        $('#productSearch').on('input', function() {
            const query = $(this).val().toLowerCase();
            $('#productTable tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(query) > -1)
            });
        });

        // Edit product function
        function editProduct(productId) {
            // Fetch product data via AJAX
            $.post('get_product.php', { id: productId }, function(data) {
                const product = JSON.parse(data);
                // Populate the modal fields with product data
                $('#edit_product_id').val(product.product_id);
                $('#edit_product_name').val(product.name);
                $('#edit_product_description').val(product.description);
                $('#edit_product_price').val(product.price);
                $('#edit_product_stock').val(product.stock);
                // Show the modal
                $('#editProductModal').modal('show');
            });
        }

        // Delete product function
        function deleteProduct(productId) {
            if (confirm("Are you sure you want to delete this product?")) {
                $.post('api/delete_product.php', { id: productId }, function(response) {
                    if (response.success) {
                        alert('Product deleted successfully.');
                        location.reload(); // Reload the page to refresh the product list
                    } else {
                        alert('Failed to delete product.');
                    }
                }, 'json');
            }
        }

        // Handle the product edit form submission
        $('#editProductForm').on('submit', function(e) {
            e.preventDefault(); // Prevent the default form submission
            const formData = $(this).serialize(); // Serialize form data

            $.post('api/update_product.php', formData, function(response) {
                if (response.success) {
                    alert('Product updated successfully.');
                    location.reload(); // Reload the page to refresh the product list
                } else {
                    alert('Failed to update product.');
                }
            }, 'json');
        });
    </script>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
